const UserModel = require('../models/UserModel.js')
const bcrypt = require('bcryptjs')

const LoginUser = async (req, res) => {
    // console.log(req.body)

    const login_username = req.body.username
    const login_password = req.body.password
    console.log(login_username, login_password)

    if (!login_username == '' && !login_password == '') {
        try {
            const login_user_data = await UserModel.findOne({ username: login_username })
            // console.log(login_user_data.name)
            const isPasswordMatch = await bcrypt.compare(login_password, login_user_data.password)
            if (isPasswordMatch) {
                const token = await login_user_data.GenerateJWTToken()
                console.log(token)
                res.json({ msg: 'Login Successful', token })
            } else {
                res.json({ msg: 'Invalid Credientials' })
            }
        } catch (err) {
            res.json({ msg: 'Invalid Credientials' })
            // console.log(err)
        }
    } else {
        res.json({ msg: 'All fields are required' })
    }
}


const RegisterUser = async (req, res) => {
    // console.log(req.body)

    const name = req.body.name
    const username = req.body.username
    const password = req.body.password
    const confirmpassword = req.body.confirmpassword

    // console.log(name,username,password)
    if (!name == '' && !username == '' && !password == '' && !confirmpassword == '') {
        if (password === confirmpassword) {
            try {

                const hash_password = await bcrypt.hash(password, 10)
                const newUser = new UserModel(
                    {
                        name: name,
                        username: username,
                        password: hash_password,

                    }
                )
                console.log(newUser)
                // const token = await newUser.GenerateJWTToken()
                // console.log(token)

                await newUser.save()
                res.json({ msg: 'Registration Successful' })

            } catch (err) {
                console.log(err)
                if (err.code == 11000) {
                    res.json({ msg: 'Username Is Already Exits' })
                }
                else {
                    res.json({ msg: 'Registration Unsuccessful' })
                }
            }
        } else {
            res.json({ msg: 'Password Not Match' })
        }
    } else {
        res.json({ msg: 'All Fields Are Required' })
    }
}
module.exports = { LoginUser, RegisterUser }